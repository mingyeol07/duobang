using UnityEngine;

public class SoundName
{
    public const string ButtonUp = "ButtonUp";
    public const string ButtonDown = "ButtonDown";
    public const string PlayerHit = "PlayerHit"; 
    public const string MonsterHit = "MonsterHit";
    public const string Sword1 = "Sword1";
    public const string Sword2 = "Sword2";
    public const string Sword3 = "Sword3";
}
